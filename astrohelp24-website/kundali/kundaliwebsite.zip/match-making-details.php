<?php
// $data = array(
//   'date' => 25,
//   'month' => 12,
//   'year' => 1988,
//   'hour' => 4,
//  'minute' => 0,
//   'latitude' => 25.123,
//   'longitude' => 82.34,
//   'timezone' => 5.5
//  );

if (isset($_POST['chartid'])) {
    echo (json_encode(getData('horo_chart_image/'.$_POST['chartid'],$_POST['data'])));
    exit();
}?>
<?php include 'header.php';?>
<?php include 'breadcrumb.php';?>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<?php
$name = $_POST['fullname'];
$time =explode(":",$_POST['m-time']);
$ftime =explode(":",$_POST['f-time']);
$data = array(
'date' => (int)date("d",strtotime($_POST['m-date'])),
'month' => (int)date("m",strtotime($_POST['m-date'])),
'year' => (int)date("Y",strtotime($_POST['m-date'])),
'hour' => $time[0],
'minute' => $time[1],
'latitude' => 25.123,
'longitude' => 82.34,
'timezone' => 5.5
);
$femaledata = array(
'date' => (int)date("d",strtotime($_POST['f-date'])),
'month' => (int)date("m",strtotime($_POST['f-date'])),
'year' => (int)date("Y",strtotime($_POST['f-date'])),
'hour' => $ftime[0],
'minute' => $ftime[1],
'latitude' => 25.123,
'longitude' => 82.34,
'timezone' => 5.5,
);

echo "chec.";
print_r($data);
$match_birth_details = getData("matchBirthDetails",$data,$femaledata);

 $match_astro_details = getData("matchAstroDetails",$data,$femaledata);
 $match_ashtakoot_points = getData("matchAshtakootPoints",$data,$femaledata);
 $match_obstructions = getData("matchObstructions",$data,$femaledata);
 $match_planet_details = getData("matchPlanetDetails",$data,$femaledata);
 $match_manglik_report = getData("getMatchManglikReport",$data,$femaledata);
 $match_making_report = getData("getMatchMakingReport",$data,$femaledata);
 $match_simple_report = getData("getMatchSimpleReport",$data,$femaledata);
//   $match_making_detailed_report = getData("getmatchMakingDetailedReport",$data,$femaledata);
//  $match_dashakoot_points = getData("match_dashakoot_points",$data,$femaledata);
// $match_percentage = getData("match_percentage",$data);
// $custom_match_profiles = getData("custom_match_profiles",$data);
// $papasamyam_details = getData("papasamyam_details",$data);
// $custom_match_profiles_xml = getData("custom_match_profiles_xml",$data);


function getData($resourceName, $data, $femaleData){
    require_once 'src/VedicRishiClient.php';
$userId = "616086";
$apiKey = "8e912f00c1e3fc41097a3a2ac79225da";
    $vedicRishi = new VedicRishiClient($userId, $apiKey);
    $responseData  = $vedicRishi->$resourceName($data, $femaleData);
    // $responseData = $vedicRishi->call($resourceName,
    // $data['m-day'], 
    // $data['m-month'],
    // $data['m-year'],
    // $data['m-hour'],
    // $data['m-min'],
    // $data['m-lat'], 
    // $data['m-lon'],
    // $data['m-tzone'],
    //   $data['f-day'], 
    // $data['f-month'],
    // $data['f-year'],
    // $data['f-hour'],
    // $data['f-min'],
    // $data['f-lat'], 
    // $data['f-lon'],
    // $data['f-tzone']
    // );
    ///echo $responseData;
    return json_decode($responseData);
    
}

?>

<div class="container marb-75 paddtop50">
    <h2 class="head-h2">Match Making</h2>
    <br><br>
 

        <div class="col-lg-12">
            
            <div class="accordion" id="accordionExample">
            


                <div class="card">
                    <div class="card-header" id="headingTwo">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Birth Details<i class="material-icons">add</i></a>
                        </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
<br>
<p class="text-center"><?php
echo "male ---> ";
 echo '<br>year        '.$match_birth_details->male_astro_details->year;
    echo '<br>gender        '.$match_birth_details->male_astro_details->gender;
    echo "female ---> ";
 echo '<br>year        '.$match_birth_details->female_astro_details->month;
    echo '<br>gender        '.$match_birth_details->demale_astro_details->ayanamsha;
?></p>

</div>
                </div>
            
</div>

                <div class="card">
                    <div class="card-header" id="headingThree">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Ashtakoot Points<i class="material-icons">add</i></a>                     
                        </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                        
                        <div class="card-body">
<br>
<p class="text-center"><?php 
echo  "<pre> match_ashtakoot_points  <br>varna";
echo  "<br> dexcription             ".$match_ashtakoot_points->varna->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->varna->male_koot_attribute;
echo  "<br>  vasya ";
echo  "<br> dexcription             ".$match_ashtakoot_points->vashya->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->vashya->male_koot_attribute;
echo  "<br>  tara ";
echo  "<br> dexcription             ".$match_ashtakoot_points->tara->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->tara->male_koot_attribute;
echo  "<br>  yoni ";
echo  "<br> dexcription             ".$match_ashtakoot_points->yoni->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->yoni->male_koot_attribute;
echo  "<br>  maitri ";
echo  "<br> dexcription             ".$match_ashtakoot_points->maitri->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->maitri->male_koot_attribute;
echo  "<br>  gan ";
echo  "<br> dexcription             ".$match_ashtakoot_points->gan->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->gan->male_koot_attribute;
echo  "<br>  bhakut ";
echo  "<br> dexcription             ".$match_ashtakoot_points->bhakut->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->bhakut->male_koot_attribute;
echo  "<br>  nadi ";
echo  "<br> dexcription             ".$match_ashtakoot_points->nadi->description;
echo  "<br> male_koot_attribute      ".$match_ashtakoot_points->nadi->male_koot_attribute;

echo  "<br>  conclusion ";

echo  "<br> report      ".$match_ashtakoot_points->conclusion->report;
?></p>

                    </div>
                </div>
</div>


                <div class="card">
                    <div class="card-header" id="headingFour">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Obstructions<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                        <div class="card-body">
                    <br>
<p class="text-center">
    <?php echo "<pre>match_obstructions  ";
            echo " is_present         ".$match_obstructions->is_present;
            echo "vedha_report        ".$match_obstructions->vedha_report;

?>
    </p>

                    </div>
                </div>
            </div>


                <div class="card">
                    <div class="card-header" id="headingFive">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Astro Details<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                        <div class="card-body">

<br>
<p class="text-center">match_astro_details
 <?php echo "<pre> match_astro_details";
    echo "<br>male details";
    echo "<br> ascendant           ".$match_astro_details->male_astro_details->ascendant;
     echo "<br> Varna           ".$match_astro_details->male_astro_details->Varna;
     echo "<br> female";
      echo "<br> ascendant           ".$match_astro_details->female_astro_details->ascendant;
       echo "<br> ascendant           ".$match_astro_details->female_astro_details->ascendant;
?>

</p>
                    </div>
                </div></div>


                <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Planet Details<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
                            <p class="text-center">match_planet_details
                             <?php 
                                echo "<pre> match_planet_details";
                                echo "<br>male";
                                 echo "<br>planet 1";
                                 echo "name          ".$match_planet_details->male_planet_details[0]->name;
                                  echo "sign         ".$match_planet_details->male_planet_details[1]->name;
                                 echo "<br>planet 2";
                                 echo "name         ".$match_planet_details->male_planet_details[1]->name;
                                  echo "<br>planet 3";
                                 echo "name         ".$match_planet_details->male_planet_details[2]->name;
                                   echo "<br>planet 8";
                                 echo "name         ".$match_planet_details->male_planet_details[8]->name;
                                 
                                  echo "<br>female";
                                 echo "<br>planet 1";
                                 echo "name          ".$match_planet_details->female_planet_details[0]->name;
                                  echo "sign         ".$match_planet_details->female_planet_details[1]->name;
                                 echo "<br>planet 2";
                                 echo "name         ".$match_planet_details->female_planet_details[1]->name;
                                  echo "<br>planet 3";
                                 echo "name         ".$match_planet_details->female_planet_details[2]->name;
                                   echo "<br>planet 8";
                                 echo "name         ".$match_planet_details->female_planet_details[8]->name;
                            ?></p>
                    </div>
                </div>
            </div>



  <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Manglik Report<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">match_planet_details
                         <?php 
                           
                           echo "<br> male ";  
                           echo "<br> male ";
                           echo "<br> manglik_present_rule ";  
                           echo "<br> based_on_aspect ";
                           echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[0];
                            echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[1];
                             echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[2];
                              echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[3];
                               echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[4];
                                echo "<br>".$match_manglik_report->male->manglik_present_rule->based_on_aspect[5];
                                echo "<br> based_on_house ";
                                echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_house[0];
                                echo  "<br>".$match_manglik_report->male->manglik_present_rule->based_on_house[1];
                                echo "<br>manglik_cancel_rule";
                                 echo  "<br>".$match_manglik_report->male->manglik_cancel_rule[0];
                             echo "<br>manglik_cancel_rule";
                              echo  "<br>".$match_manglik_report->male->is_mars_manglik_cancelled;
                                
                       
                           echo "<br> female ";
                           echo "<br> manglik_present_rule ";  
                           echo "<br> based_on_aspect ";
                           echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[0];
                            echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[1];
                             echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[2];
                              echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[3];
                               echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[4];
                                echo "<br>".$match_manglik_report->female->manglik_present_rule->based_on_aspect[5];
                                echo "<br> based_on_house ";
                                echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_house[0];
                                echo  "<br>".$match_manglik_report->female->manglik_present_rule->based_on_house[1];
                                echo "<br>manglik_cancel_rule";
                                 echo  "<br>".$match_manglik_report->female->manglik_cancel_rule[0];
                             echo "<br>manglik_cancel_rule";
                              echo  "<br>".$match_manglik_report->female->is_mars_manglik_cancelled;
                              
                            
                        ?></p>
</div>
                </div>
            </div>


              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Making Report<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">match_making_report
    <?php 
    echo "match_making_report<pre> ";
    print_r($match_making_report);
    
    ?>
</p>
</div>
                </div>
            </div>

              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Simple Report<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">
    <?php echo "match_making_report<pre> ";
    print_r($match_simple_report);
    ?></p>
</div>
                </div>
            </div>

              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Making Detailed Report<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>

              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Dashakoot Points<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>

              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Match Percentage<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>
              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Partner Report<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>  <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Custom Match Profiles<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>
              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Custom Match Profiles xml<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>
              <div class="card">
                    <div class="card-header" id="headingsix">
                        <h2 class="mb-0">
                            <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix"><i class="fa fa-angle-double-right" style="float: left; top: 2px; padding-right: 8px;"></i>Papasamyam Details<i class="material-icons">add</i></a>                               
                        </h2>
                    </div>
                    <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                        <div class="card-body">
                            <br>
<p class="text-center">Result Text</p>
</div>
                </div>
            </div>
              


            </div>
        </div>


</div>


<script>
$(document).ready(function(){
    // Add minus icon for collapse element which is open by default
    $(".collapse.show").each(function(){
        $(this).siblings(".card-header").find(".btn i").html("remove");
        $(this).prev(".card-header").addClass("highlight");
    });
    
    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function(){
        $(this).parent().find(".card-header .btn i").html("remove");
    }).on('hide.bs.collapse', function(){
        $(this).parent().find(".card-header .btn i").html("add");
    });
});

</script>
<?php include 'footer.php';?>


