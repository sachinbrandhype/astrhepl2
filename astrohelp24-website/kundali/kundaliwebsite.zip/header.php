<!DOCTYPE html>
<html lang="zxx">
<?php include 'config.php';?>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <meta name="keywords" content="Fashi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Astrologer</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="http://astrohelp24.com/assets/css/style.css">
<body>
  

    <!-- Header Section Begin -->

    <header class="header">
    
       <nav class="navbar navbar-expand-lg header-nav">
               <div class="navbar-header">
                  <a id="mobile_btn" href="javascript:void(0);">
                  <span class="bar-icon">
                  <span></span>
                  <span></span>
                  <span></span>
                  </span>
                  </a>
                  <a href="http://astrohelp24.com/" class="navbar-brand logo">
                  <img src="http://astrohelp24.com/assets/img/logo.png" class="img-fluid" alt="Logo">
                  </a>
               </div>
               <div class="main-menu-wrapper">
                  <div class="menu-header">
                     <a href="http://astrohelp24.com/" class="menu-logo">
                     <img src="http://astrohelp24.com/assets/img/logo.png" class="img-fluid" alt="Logo">
                     </a>
                     <a id="menu_close" class="menu-close" href="javascript:void(0);">
                     <i class="fa fa-times"></i>
                     </a>
                  </div>
                  <ul class="main-nav">
                     <li class=" active">
                        <a href="http://astrohelp24.com/">Home</a>
                     </li>
                     <li class="">
                        <a href="http://astrohelp24.com/home/about_us">About Us</a>
                     </li>
                     <li class="has-submenu">
                        <a href="">Services <i class="fa fa-chevron-down"></i></a>
                        <ul class="submenu">
                           <li><a href="http://astrohelp24.com/home/astrologer_list">Consult Astrologer</a></li>
                           <li class="has-submenu">
                              <a href="#">Report</a>
                              <ul class="submenu">
                                 <li><a href="http://astrohelp24.com/home/career_report">Career Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Education Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Marriage Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Love Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Child Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Business Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Foreign Report</a></li>
                                 <li><a href="http://astrohelp24.com/home/career_report">Property Report</a></li>
                              </ul>
                           </li>
                           <li class="has-submenu">
                              <a href="#">Courses</a>
                              <ul class="submenu">
                                 <li><a href="http://astrohelp24.com/home/astrology_course">Astrology Courses</a></li>
                                 <li><a href="http://astrohelp24.com/home/astrology_course">Tarot Course</a></li>
                                 <li><a href="http://astrohelp24.com/home/astrology_course">Vastu Course</a></li>
                                 <li><a href="http://astrohelp24.com/home/astrology_course">Palmistry Course</a></li>
                              </ul>
                           </li>
                           <li class="has-submenu">
                              <a href="#">Vastu Consultant</a>
                              <ul class="submenu">
                                 <li><a href="http://astrohelp24.com/home/office_vastu">Home /office Vastu</a></li>
                                 <li><a href="http://astrohelp24.com/home/office_vastu">Industrial Vastu</a></li>
                              </ul>
                           </li>
                           <li><a href="http://astrohelp24.com/home/horoscopes">Free Horoscope</a></li>
                           <li><a href="http://astrohelp24.com/home/horoscopes">Marriage Matching</a></li>
                           <li><a href="http://astrohelp24.com/home/horoscopes">Numerology</a></li>
                           <li><a href="http://astrohelp24.com/home/horoscopes">Today's Panchang</a></li>
                        </ul>
                     </li>
                     <li class="">
                        <a href="http://astrohelp24.com/sdauth/filter_astrologers" class="highlight">Consult Astrologers</a>
                        <!-- <a href="http://astrohelp24.com/home/astrologer_list" class="highlight">Consult Astrologers</a> -->
                     </li>

                      <li class="">
                             <a class="" href="http://astrohelp24.com/kundali?id=<?= base64_encode($session_data->id) ?>">Kundli</a>
                         </li>

                     <li class="">
                        <a href="http://astrohelp24.com/home/contact">Contact Us</a>
                     </li>
                     
                  </ul>
               </div>
               
            </nav>
        <div class="nav-item">
            <div class="container">
             
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                         
                        
                         <li><a href="#">Free Reports <i class="fa fa-chevron-down"></i></a>
                            <ul class="dropdown">
                                <li><a href="kundali-form.php">Kundali</a></li>
                               <li><a href="daily-horoscope-details.php">Daily Horoscope</a></li>
                               
                                <li><a href="numerology-details.php">Numerology</a></li>
                                <li><a href="lalkitab.php">Lal Kitab</a></li>
                                <li><a href="kp-system.php">KP System</a></li>
                                 <li><a href="lifereport.php">Life Report</a></li>
                                <li><a href="lucky-number-details.php">Know Your Lucky Number</a></li>
                                <li><a href="sadhesati-remedies-details.php">Sade Sati</a></li>
                               
                                <li><a href="puja-suggestion-details.php">Puja Suggestion</a></li>
                                <li><a href="lucky-colour-details.php">Know Your Lucky Colour</a></li>
                                <li><a href="rudraksha-suggestion-details.php">Rudraksh Suggestion</a></li>
                                <li><a href="gemstone-suggestion-details.php">Gemstone Suggestion</a></li>
                               
                                <li><a href="panchang-details.php">Daily Panchang</a></li>
                                <li><a href="daily-prediction-details.php">Daily Prediction</a></li>
                                

                            </ul>
                        </li>
                         
                        
                    
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->