
   <div class="partner-logo">
        <div class="container footer-top">
            <div class="row">
            <div class="col-lg-9">
                <h2 class="footer-top-h2">
                   About Us
                </h2>
                <p class="text-left">
                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </p>
            </div>
            <div class="col-lg-3">
                 <h2 class="footer-top-h2">
                   Important Links
                </h2>
                <ul>
                    <li><a href="#">Kundli (Birth Chart)</a></li>
                    <li><a href="#">Horoscope Matching</a></li>
                    <li><a href="#">Kundali Expert Matrimony</a></li>
                    <li><a href="#">Ask a Question</a></li>
                    <li><a href="#">Career Counselling</a></li>
                    <li><a href="#">Life Report</a></li>
                </ul>
            </div>
            </div>

        </div>
    </div>
    

    <!-- Footer Section Begin -->
    <footer class="footer-section footer-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <p class="callt"><img src="img/footer-phone.png"></p>
<p class="footer-top-t-pad"><span class="footer-spcall">Call Us</span><br>
<a href="tel:+91 9999 999 999" class="footer-top-tel">+91 9999 999 999</a>
</p>
                </div>
            
                <div class="col-lg-4">
                    <p class="callt"><img src="img/footer-email.png"></p>
<p class="footer-top-t-pad"><span class="footer-spcall">Mail At</span><br>
<a href="mailto:info@example.com" class="footer-top-tel">info@example.com</a>
</p>
                </div>
                  <div class="col-lg-4">
                    <p class="callt"><img src="img/footer-location.png"></p>
<p class="footer-top-t-pad"><span class="footer-spcall">Location</span><br>
<a href="#" class="footer-top-tel">Delhi</a>
</p>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 

                        </div>
                      
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>