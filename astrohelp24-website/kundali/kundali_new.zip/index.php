<?php $id = $_GET['id'];
$id = base64_decode($id);
session_start();
$_SESSION['user_id'] = $id;

?>
<?php include 'header.php';?>

    <!-- Hero Section Begin -->
    <section class="hero-section">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Carousel indicators -->
                 
                <!-- Wrapper for carousel items -->
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/slider-1.jpg" class="img-fluid" alt="Notebook">
                    
                
                    </div>  
                   <div class="carousel-item">
                        <img src="img/slider-2.jpg" class="img-fluid" alt="Notebook">
                
                    </div> 

                     
                </div>
                <!-- Carousel controls -->
                <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
    </section>
    <!-- Hero Section End -->




<section class="padd-top-30">
        <div class="container">
            <div class="row">

                <div class="col-lg-4">



<div class="left-panel">
<div class="main-box">
<h2>Free Reports</h2>
</div>    
<ul class="all-report">
  <li><span class="link-block"><a href="kundali-form.php">Kundali</a></span></li> 
  <li><span class="link-block"><a href="daily-horoscope-details.php">Daily Horoscope</a></span></li> 
  <li><span class="link-block"><a href="numerology-details.php">Numerology</a></span></li> 
  <li><span class="link-block"><a href="lalkitab.php">Lal Kitab</a></span></li>
  <li><span class="link-block"><a href="kp-system.php">KP System</a></span></li> 
  <li><span class="link-block"><a href="lifereport.php">Life Report</a></span></li> 
  <li><span class="link-block"><a href="lucky-number-details.php">Know Your Lucky Number</a></span></li> 
  <li><span class="link-block"><a href="sadhesati-remedies-details.php">Sade Sati</a></span></li>  
  <li><span class="link-block"><a href="match-making.php">Match Making</a></span></li> 
  <li><span class="link-block"><a href="puja-suggestion-details.php">Puja Suggestion</a></span></li>  
  <li><span class="link-block"><a href="lucky-colour-details.php">Know Your Lucky Colour</a></span></li>  
  <li><span class="link-block"><a href="rudraksha-suggestion-details.php">Rudraksh Suggestion</a></span></li>  
  <li><span class="link-block"><a href="gemstone-suggestion-details.php">Gemstone Suggestion</a></span></li>  
  <li><span class="link-block"><a href="panchang-details.php">Daily Panchang</a></span></li>  
  <li><span class="link-block"><a href="daily-prediction-details.php">Daily Prediction</span></a></li>   
 
</ul>
</div>




                </div>
                <div class="col-lg-8">
                    
                    <div class="section-title">
                         <h3>Know More About </h3>
                    <h2>Astrologer</h2>
                    <p class="text-center">
                    <img src="img/head-sep.png" alt=""></p>
                    </div>
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

<p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                   
                   
                </div>
          
        </div>
    </div>
</section>




<section class="padd-top-30 ">
    <div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="stats">
                <p><img src="img/experience.png" alt=""></p>
                <p>21+ Years Experience</p>
            </div>
        </div>
       <div class="col-md-3">
            <div class="stats">
                <p><img src="img/satisfaction.png" alt=""></p>
                <p>100% Satisfaction</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats">
                <p><img src="img/trusted-clients.png" alt=""></p>
                <p>2500+ Trusted Clients</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats">
                <p><img src="img/followers.png" alt=""></p>
                <p>20+ Countries Followers</p>
            </div>
        </div>
    </div>
</div>
    </section>




    
   
<?php include 'footer.php';?>