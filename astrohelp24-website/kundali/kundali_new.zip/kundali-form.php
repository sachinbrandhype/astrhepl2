<?php
session_start();
if($_SESSION['user_id']) {
$user_id =  $_SESSION['user_id'];
}   
?>
<?php include 'header.php';?>
<?php include 'breadcrumb.php';
$query = "SELECT name,dob,birth_time,place_of_birth FROM user WHERE id='".$user_id."'"; 
   $result = $conn ->query($query);
   $row = $result->fetch_row();
  
  if($_POST) {
	  //print_r($_POST);die;
	  $sql = "INSERT INTO `members` (`user_id`, `type`, `name`, `fathername`, `mothername`, `email`, `phone`, `zodiac`, `occupation`, `dob`, `tob`, `gender`, `pob`, `gotro`, `spouse`, `relation`, `location`, `latitude`, `longitude`, `is_default`, `status`, `created_at`)
VALUES ('".$user_id."', 'host', '".$_POST['fullname']."', NULL, NULL, NULL, NULL, NULL, NULL, '".$_POST['date']."', '".$_POST['time']."', NULL, '".$_POST['place']."', NULL, NULL, NULL, NULL, '0.00000000', '0.00000000', '1', '1', '0000-00-00 00:00:00')";
 $result = $conn ->query($sql);
 echo "Kundali Submited Successfully!";
  }
?>

    
    <div class="register-login-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="register-form">
                        <h2>kundali</h2>
                      <form method='post' action=''>
                           
<div class="group-input">
                                <label for="username">Name</label>
                                <input  name="fullname" placeholder="Name" required="" value="<?php echo $row[0];?>">
                            </div>

                            
                            <div class="group-input">
                                <label for="pass">Date</label>

                                <input  name="date" type='date'  placeholder="Date of Year" required="" value="<?php echo $row[1];?>">
                            </div>



                           <div class="group-input">
                                <label for="pass">Time</label>

                                <input  name="time" type='time' required="" value="<?php echo $row[0];?>">
                            </div>  
                     
                            <div class="group-input" style='display:none'> 
                                <label for="pass">Latitude</label>
                                <input id="latitude" readonly name="latitude"  placeholder="Latitude">
                            </div>


                             <div class="group-input" style='display:none'> 
                                <label for="pass">Longitude</label>
                                <input id="longitude" readonly name="longitude"  placeholder="Longitude">
                            </div>

                            <div class="group-input"> 
                            <div class="autocomplete">
                                <label for="pass">Place</label>
                                <input id="place"  name="place" onkeyup="placeAPI(this.value)"  placeholder="Search Place Name e.g. New Delhi, Mumbai etc." required="" value="<?php echo $row[3];?>">
                            </div>
                            </div>



                            <button type="submit" class="site-btn register-btn">Submit Now</button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Register Form Section End -->
    

<?php include 'footer.php';?>

<script src="place-api.js"></script>
    
