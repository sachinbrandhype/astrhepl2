<?php include 'header.php';?>
<?php include 'breadcrumb.php';?>

    
    <div class="register-login-section spad">
        <div class="container">
             <form method='post' action='match-making-details.php'>
            <div class="row">
               
                <div class="col-lg-6">
                    <div class="register-form">
                        <h2>Boy Details</h2>
                      <!--<form method='post' action='match-making-details.php'>-->
                           
<div class="group-input">
                                <label for="username">Name</label>
                                <input  name="fullname" placeholder="Name" required="">
                            </div>

                            
                            <div class="group-input">
                                <label for="pass">Date</label>

                                <input  name="m-date" type='date'  placeholder="Date of Year" required="">
                            </div>



                           <div class="group-input">
                                <label for="pass">Time</label>

                                <input  name="m-time" type='time' required="">
                            </div>  
                     
                            <div class="group-input" style='display:none'> 
                                <label for="pass">Latitude</label>
                                <input id="m-latitude" readonly name="latitude"  placeholder="Latitude">
                            </div>


                             <div class="group-input" style='display:none'> 
                                <label for="pass">Longitude</label>
                                <input id="lm-ongitude" readonly name="longitude"  placeholder="Longitude">
                            </div>

                            <div class="group-input"> 
                            <div class="autocomplete">
                                <label for="pass">Place</label>
                                <input id="place"  name="place" onkeyup="placeAPI(this.value)"  placeholder="Search Place Name e.g. New Delhi, Mumbai etc." required="">
                            </div>
                            </div>



                            <!--<button type="submit" class="site-btn register-btn">Submit Now</button>-->
                        <!--</form>-->
                        
                    </div>
                </div>

                 <div class="col-lg-6">
                    <div class="register-form">
                        <h2>Girl Details</h2>
                      <!--<form method='post' action='lifereport-details.php'>-->
                           
<div class="group-input">
                                <label for="username">Name</label>
                                <input  name="fullname" placeholder="Name" required="">
                            </div>

                            
                            <div class="group-input">
                                <label for="pass">Date</label>
                                <input  name="f-date" type='date'  placeholder="Date of Year" required="">
                            </div>



                           <div class="group-input">
                                <label for="pass">Time</label>

                                <input  name="f-time" type='time' required="">
                            </div>  
                     
                            <div class="group-input" style='display:none'> 
                                <label for="pass">Latitude</label>
                                <input id="f-latitude" readonly name="latitude"  placeholder="Latitude">
                            </div>


                             <div class="group-input" style='display:none'> 
                                <label for="pass">Longitude</label>
                                <input id="f-longitude" readonly name="longitude"  placeholder="Longitude">
                            </div>

                            <div class="group-input"> 
                            <div class="autocomplete">
                                <label for="pass">Place</label>
                                <input id="place"  name="place" onkeyup="placeAPI(this.value)"  placeholder="Search Place Name e.g. New Delhi, Mumbai etc." required="">
                            </div>
                            </div>



                            <button type="submit" class="site-btn register-btn">Submit Now</button>
                        <!--</form>-->
                        
                    </div>
                </div>
                
            </div>
            </form>
        </div>
    </div>
    <!-- Register Form Section End -->
    

<?php include 'footer.php';?>

<script src="place-api.js"></script>
    
