<!DOCTYPE html>
<html lang="zxx">
<?php include 'config.php';?>
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <meta name="keywords" content="Fashi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Astrologer</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
  

    <!-- Header Section Begin -->
    <header class="header-section">
    
        <div class="bg-header">
        <div class="container">
            <div class="inner-header">
                <div class="row">
        <div class="col-lg-3 col-md-3 phone-top">
                       <p class="callt"><img src="img/phone-icon.png"></p>
<p class="top-t-pad"><span class="spcall">Talk to Astrologer</span><br>
<a href="tel:+91 9818 318 303" class="top-tel">+91 9999 999 999</a>
</p>
                    </div>
                     <div class="col-lg-1 col-md-1"></div>
                     <div class="col-lg-4 col-md-4">
                        <div class="logo">
                            <a href="index.php">
                                <img src="img/astro-logo.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-1 col-md-1"></div>
                   <div class="col-lg-3 col-md-3">
             <div class="top-book">       
<p class="top-t-pad">
<a href="#" class="book">Book An Appointment</a>
</p>
</div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
        <div class="nav-item">
            <div class="container">
             
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                         
                        
                         <li><a href="#">Free Reports <i class="fa fa-chevron-down"></i></a>
                            <ul class="dropdown">
                                <li><a href="kundali-form.php">Kundali</a></li>
                               <li><a href="daily-horoscope-details.php">Daily Horoscope</a></li>
                               
                                <li><a href="numerology-details.php">Numerology</a></li>
                                <li><a href="lalkitab.php">Lal Kitab</a></li>
                                <li><a href="kp-system.php">KP System</a></li>
                                 <li><a href="lifereport.php">Life Report</a></li>
                                <li><a href="lucky-number-details.php">Know Your Lucky Number</a></li>
                                <li><a href="sadhesati-remedies-details.php">Sade Sati</a></li>
                               
                                <li><a href="puja-suggestion-details.php">Puja Suggestion</a></li>
                                <li><a href="lucky-colour-details.php">Know Your Lucky Colour</a></li>
                                <li><a href="rudraksha-suggestion-details.php">Rudraksh Suggestion</a></li>
                                <li><a href="gemstone-suggestion-details.php">Gemstone Suggestion</a></li>
                               
                                <li><a href="panchang-details.php">Daily Panchang</a></li>
                                <li><a href="daily-prediction-details.php">Daily Prediction</a></li>
                                

                            </ul>
                        </li>
                         
                        
                    
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->